# Advanced Messenger v2.0 - Projet Kotlin Android

## Structure du projet

- `app/src/main/java/com/advancedmessenger/` : Code source Kotlin complet
  - `MainActivity.kt` : Écran principal + liste utilisateurs
  - `SettingsActivity.kt` : Paramètres + mode expert
  - `P2PService.kt` : Service en arrière-plan
  - `CallActivity.kt` : Écran d'appel avec contrôle qualité live

- Layouts complets fournis

## Comment builder l'APK

1. Ouvrez le dossier `advanced-messenger` dans **Android Studio** (version Hedgehog ou supérieure recommandée)
2. Attendez la synchronisation Gradle
3. Cliquez sur **Build → Build Bundle(s) / APK(s) → Build APK(s)**
4. L'APK sera généré dans :
   `app/build/outputs/apk/debug/app-debug.apk`

## Fonctionnalités implémentées (version de base)

- Pseudo + connexion simulée P2P
- Liste des utilisateurs connectés
- Envoi message / appel audio / vidéo / fichier
- Service foreground (arrière-plan)
- Réglage qualité/débit en direct pendant appel
- Mode Expert (switch)
- Logs détaillés
- Compatible Android 7.0 → Android 15

## Prochaines étapes possibles

- Intégration WebRTC réelle
- Découverte P2P (libp2p ou mDNS)
- Chiffrement de bout en bout
- Mode développeur avancé (logs + options)

Le projet est prêt à être ouvert et compilé.