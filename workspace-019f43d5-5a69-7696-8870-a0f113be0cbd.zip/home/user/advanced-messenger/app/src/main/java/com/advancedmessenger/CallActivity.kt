package com.advancedmessenger

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class CallActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_call)

        val target = intent.getStringExtra("target") ?: "Inconnu"
        val type = intent.getStringExtra("type") ?: "audio"

        findViewById<TextView>(R.id.txtCallInfo).text = "Appel $type en cours avec $target"

        findViewById<Button>(R.id.btnEndCall).setOnClickListener {
            finish()
        }

        // Sliders pour qualité en direct (mode expert)
        val qualitySlider = findViewById<SeekBar>(R.id.seekLiveQuality)
        qualitySlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    findViewById<TextView>(R.id.txtQuality).text = "Qualité live : $progress%"
                }
            }
            override fun onStartTrackingTouch(p0: SeekBar?) {}
            override fun onStopTrackingTouch(p0: SeekBar?) {}
        })
    }
}