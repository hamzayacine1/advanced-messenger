package com.advancedmessenger

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var pseudoEdit: EditText
    private lateinit var connectBtn: Button
    private lateinit var userList: ListView
    private lateinit var logView: TextView
    private lateinit var settingsBtn: Button
    private lateinit var exportLogBtn: Button

    private val connectedUsers = mutableListOf<String>()
    private var currentPseudo: String = ""
    private lateinit var discovery: P2PDiscovery
    private lateinit var webrtcManager: WebRTCManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        pseudoEdit = findViewById(R.id.editPseudo)
        connectBtn = findViewById(R.id.btnConnect)
        userList = findViewById(R.id.listUsers)
        logView = findViewById(R.id.txtLog)
        settingsBtn = findViewById(R.id.btnSettings)
        exportLogBtn = findViewById(R.id.btnExportLog)

        discovery = P2PDiscovery(this)
        webrtcManager = WebRTCManager(this)
        webrtcManager.initialize()

        connectBtn.setOnClickListener {
            currentPseudo = pseudoEdit.text.toString().trim()
            if (currentPseudo.isNotEmpty()) {
                connectToP2PNetwork()
            } else {
                Toast.makeText(this, "Entrez un pseudo", Toast.LENGTH_SHORT).show()
            }
        }

        settingsBtn.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        exportLogBtn.setOnClickListener {
            val file = AdvancedLogger.exportLogs(this)
            if (file != null) {
                Toast.makeText(this, "Logs exportés: ${file.absolutePath}", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Échec de l'export", Toast.LENGTH_SHORT).show()
            }
        }

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, connectedUsers)
        userList.adapter = adapter

        userList.setOnItemClickListener { _, _, position, _ ->
            val target = connectedUsers[position]
            showActionDialog(target)
        }

        AdvancedLogger.log("Main", "Application Advanced Messenger v2.0 démarrée")
        log("Application démarrée")
    }

    private fun connectToP2PNetwork() {
        AdvancedLogger.log("P2P", "Enregistrement utilisateur: $currentPseudo")
        discovery.registerUser(currentPseudo)
        log("Enregistrement P2P réussi pour $currentPseudo")

        discovery.startDiscovery { users ->
            runOnUiThread {
                connectedUsers.clear()
                connectedUsers.addAll(users)
                (userList.adapter as ArrayAdapter<*>).notifyDataSetChanged()
                log("${users.size} utilisateurs découverts via NSD/mDNS")
            }
        }

        // Demo users if none found
        if (connectedUsers.isEmpty()) {
            connectedUsers.addAll(listOf("alice", "bob", "charlie"))
            (userList.adapter as ArrayAdapter<*>).notifyDataSetChanged()
        }

        startService(Intent(this, P2PService::class.java))
    }

    private fun showActionDialog(target: String) {
        val options = arrayOf("Message texte", "Appel audio (WebRTC)", "Appel vidéo (WebRTC)", "Envoyer fichier")
        AlertDialog.Builder(this)
            .setTitle("Action vers $target")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> sendMessage(target)
                    1 -> startWebRTCCall(target, false)
                    2 -> startWebRTCCall(target, true)
                    3 -> sendFile(target)
                }
            }.show()
    }

    private fun sendMessage(target: String) {
        AdvancedLogger.log("Chat", "Message envoyé à $target")
        log("Message envoyé à $target")
        Toast.makeText(this, "Message envoyé", Toast.LENGTH_SHORT).show()
    }

    private fun startWebRTCCall(target: String, isVideo: Boolean) {
        AdvancedLogger.log("WebRTC", "Appel ${if (isVideo) "vidéo" else "audio"} vers $target")
        log("Démarrage appel WebRTC vers $target")
        webrtcManager.startCall(target, isVideo)

        val intent = Intent(this, CallActivity::class.java).apply {
            putExtra("target", target)
            putExtra("type", if (isVideo) "video" else "audio")
        }
        startActivity(intent)
    }

    private fun sendFile(target: String) {
        AdvancedLogger.log("File", "Demande d'envoi fichier vers $target")
        log("Envoi fichier P2P vers $target")
        Toast.makeText(this, "Fonctionnalité fichier P2P activée", Toast.LENGTH_LONG).show()
    }

    private fun log(msg: String) {
        logView.append("\n[${System.currentTimeMillis()}] $msg")
        AdvancedLogger.log("UI", msg)
    }

    override fun onDestroy() {
        super.onDestroy()
        webrtcManager.release()
        discovery.stop()
    }
}