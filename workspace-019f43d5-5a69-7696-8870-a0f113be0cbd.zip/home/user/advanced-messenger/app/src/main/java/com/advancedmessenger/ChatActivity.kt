package com.advancedmessenger

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class ChatActivity : AppCompatActivity() {

    private lateinit var chatLog: TextView
    private lateinit var messageInput: EditText
    private lateinit var sendBtn: Button
    private var targetUser: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        targetUser = intent.getStringExtra("target") ?: "Inconnu"

        chatLog = findViewById(R.id.txtChatLog)
        messageInput = findViewById(R.id.editMessage)
        sendBtn = findViewById(R.id.btnSend)

        findViewById<TextView>(R.id.txtChatTitle).text = "Discussion avec $targetUser"

        sendBtn.setOnClickListener {
            val msg = messageInput.text.toString().trim()
            if (msg.isNotEmpty()) {
                sendP2PMessage(msg)
                messageInput.text.clear()
            }
        }

        AdvancedLogger.log("Chat", "Chat ouvert avec $targetUser")
    }

    private fun sendP2PMessage(message: String) {
        chatLog.append("\nMoi: $message")
        AdvancedLogger.log("Chat", "Message P2P envoyé à $targetUser: $message")
        // In real app: send via WebRTC DataChannel
        Toast.makeText(this, "Message envoyé via P2P", Toast.LENGTH_SHORT).show()
    }
}