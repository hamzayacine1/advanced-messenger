package com.advancedmessenger

import android.content.Context
import android.os.Environment
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.*

object AdvancedLogger {

    private val logs = mutableListOf<String>()
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault())

    fun log(tag: String, message: String) {
        val timestamp = dateFormat.format(Date())
        val entry = "[$timestamp] [$tag] $message"
        logs.add(entry)
        println(entry) // Also print to console
    }

    fun getAllLogs(): String = logs.joinToString("\n")

    fun exportLogs(context: Context): File? {
        return try {
            val downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val file = File(downloads, "advanced_messenger_logs_${System.currentTimeMillis()}.txt")
            FileWriter(file).use { it.write(getAllLogs()) }
            file
        } catch (e: Exception) {
            log("Logger", "Export failed: ${e.message}")
            null
        }
    }

    fun clear() {
        logs.clear()
    }
}