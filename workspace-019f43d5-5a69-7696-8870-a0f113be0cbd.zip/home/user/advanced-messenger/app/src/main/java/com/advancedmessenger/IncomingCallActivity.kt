package com.advancedmessenger

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class IncomingCallActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_incoming_call)

        val caller = intent.getStringExtra("caller") ?: "Inconnu"
        val type = intent.getStringExtra("type") ?: "audio"

        findViewById<TextView>(R.id.txtIncomingCall).text =
            "Appel $type entrant de $caller"

        findViewById<Button>(R.id.btnAccept).setOnClickListener {
            // Accept call → start CallActivity
            val intent = Intent(this, CallActivity::class.java).apply {
                putExtra("target", caller)
                putExtra("type", type)
            }
            startActivity(intent)
            finish()
        }

        findViewById<Button>(R.id.btnReject).setOnClickListener {
            AdvancedLogger.log("Call", "Appel rejeté de $caller")
            finish()
        }
    }
}