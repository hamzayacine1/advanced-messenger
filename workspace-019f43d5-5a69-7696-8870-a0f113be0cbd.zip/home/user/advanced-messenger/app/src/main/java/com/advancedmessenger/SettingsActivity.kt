package com.advancedmessenger

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val qualitySeek = findViewById<SeekBar>(R.id.seekVideoQuality)
        val bitrateSeek = findViewById<SeekBar>(R.id.seekBitrate)
        val expertSwitch = findViewById<Switch>(R.id.switchExpert)
        val saveBtn = findViewById<Button>(R.id.btnSave)

        qualitySeek.progress = 70
        bitrateSeek.progress = 50

        expertSwitch.setOnCheckedChangeListener { _, checked ->
            if (checked) {
                Toast.makeText(this, "Mode Expert activé - options avancées débloquées", Toast.LENGTH_LONG).show()
            }
        }

        saveBtn.setOnClickListener {
            val quality = qualitySeek.progress
            val bitrate = bitrateSeek.progress
            Toast.makeText(this, "Paramètres sauvegardés : Qualité=$quality%, Bitrate=$bitrate kbps", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}