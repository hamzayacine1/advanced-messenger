package com.advancedmessenger

import android.app.*
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat

class P2PService : Service() {

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(1, createNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Ici on lancerait le vrai moteur P2P (WebRTC, libp2p, etc.)
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            "p2p_channel",
            "Advanced Messenger P2P",
            NotificationManager.IMPORTANCE_LOW
        )
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(channel)
    }

    private fun createNotification(): Notification {
        return NotificationCompat.Builder(this, "p2p_channel")
            .setContentTitle("Advanced Messenger v2.0")
            .setContentText("Service P2P actif en arrière-plan")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
    }
}